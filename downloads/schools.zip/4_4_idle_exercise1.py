# 4.4. Geoprocessing in IDLE - Exercise 1

import arcpy

# Replace "your_path" with the path where you save the geodatabase
arcpy.env.workspace = "c:/test/schools.gdb"

# Create buffers around schools
arcpy.Buffer_analysis("denver_schools","school_buffer_500","500 feet")

print "Buffer processing finished!"
