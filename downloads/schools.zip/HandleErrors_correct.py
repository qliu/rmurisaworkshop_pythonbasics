import arcpy

# Set up variables
schools = r"schools.gdb\DenverSchools2013"
buff_distances = [100,200]

# Loop through the buffer distance list and create buffers
for buff in buff_distances:
    print "Buffer " + str(buff) + " is processing..."
    arcpy.Buffer_analysis(schools,schools+str(buff),buff)

# Write a print statement so user know when script execution has finished
print "Buffer processing finished."
