# 6.2 Create Script Tool

# Import the arcpy and os modules.
import arcpy
import os

# Input feature classes to buffer.
in_fcs = "C:/your_path/denver_schools.shp"

# Output workspace.
out_ws = "C:/your_path/schools.gdb"

# Buffer distance.
dist = 1000

# Split input feature classes into separate feature classes.
in_fcs = in_fcs.split(";")

# Loop through each feature class and create buffers.
for in_fc in in_fcs:
    # Figure out the name of the output feature class.
    (file_path, file_name) = os.path.split(in_fc)
    dot_index = file_name.find(".")
    if dot_index <> -1:
        new_fc = file_name[0:dot_index]
        out_fc = new_fc + "_buffer"
    else:
        out_fc = file_name + "_buffer"    

    # Create the buffer feature class.
    arcpy.Buffer_analysis(in_fc, out_ws + "\\" + out_fc, str(dist) + " Feet")
